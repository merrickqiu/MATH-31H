The scenes are in /scenes and the renderings are in /output.
I implemented a rotating light for the lighting animation bonus.
For part 5, I made a scene called pseudomolecule.json to demonstrate that you can
use this to render spacefill models of molecules.
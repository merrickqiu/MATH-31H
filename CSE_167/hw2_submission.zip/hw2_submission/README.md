I created a new scene called scenes/cow.json.
This is copied from [sample files from FSU](https://people.sc.fsu.edu/~jburkardt/data/ply/ply.html).